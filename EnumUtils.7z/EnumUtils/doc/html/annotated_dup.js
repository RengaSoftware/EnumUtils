var annotated_dup =
[
    [ "enum_utils", null, [
      [ "array", "structenum__utils_1_1array.html", "structenum__utils_1_1array" ],
      [ "bad_conversion", "classenum__utils_1_1bad__conversion.html", null ],
      [ "bad_mapping", "classenum__utils_1_1bad__mapping.html", null ],
      [ "conversion_generator", "structenum__utils_1_1conversion__generator.html", [
        [ "impl", "structenum__utils_1_1conversion__generator_1_1impl.html", "structenum__utils_1_1conversion__generator_1_1impl" ]
      ] ],
      [ "exception", "classenum__utils_1_1exception.html", null ],
      [ "iterator", "structenum__utils_1_1iterator.html", "structenum__utils_1_1iterator" ],
      [ "mapped_type", "structenum__utils_1_1mapped__type.html", null ],
      [ "mapped_value", "structenum__utils_1_1mapped__value.html", null ],
      [ "range", "structenum__utils_1_1range.html", "structenum__utils_1_1range" ],
      [ "sequence", "structenum__utils_1_1sequence.html", null ],
      [ "traits", "structenum__utils_1_1traits.html", null ],
      [ "validator", "structenum__utils_1_1validator.html", null ]
    ] ]
];