var hierarchy =
[
    [ "array< E, T >", "structenum__utils_1_1array.html", null ],
    [ "exception", null, [
      [ "exception", "classenum__utils_1_1exception.html", [
        [ "bad_conversion", "classenum__utils_1_1bad__conversion.html", null ],
        [ "bad_mapping", "classenum__utils_1_1bad__mapping.html", null ]
      ] ]
    ] ],
    [ "conversion_generator< E, T >::impl< e >", "structenum__utils_1_1conversion__generator_1_1impl.html", null ],
    [ "iterator", null, [
      [ "iterator< E >", "structenum__utils_1_1iterator.html", null ]
    ] ],
    [ "mapped_type< E, e, Tag >", "structenum__utils_1_1mapped__type.html", null ],
    [ "mapped_value< E, e, T >", "structenum__utils_1_1mapped__value.html", null ],
    [ "sequence< E, es >", "structenum__utils_1_1sequence.html", null ],
    [ "traits< E >", "structenum__utils_1_1traits.html", null ],
    [ "traits_validator< E >", null, [
      [ "validator< E >", "structenum__utils_1_1validator.html", [
        [ "conversion_generator< E, T >", "structenum__utils_1_1conversion__generator.html", null ],
        [ "iterator< E >", "structenum__utils_1_1iterator.html", null ],
        [ "range< E >", "structenum__utils_1_1range.html", null ]
      ] ]
    ] ],
    [ "type_validator< E >", null, [
      [ "validator< E >", "structenum__utils_1_1validator.html", null ]
    ] ]
];