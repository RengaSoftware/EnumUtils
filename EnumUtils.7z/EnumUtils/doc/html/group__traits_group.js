var group__traits_group =
[
    [ "traits", "structenum__utils_1_1traits.html", null ],
    [ "validator", "structenum__utils_1_1validator.html", null ],
    [ "ENUM_UTILS_DEFINE_TRAITS", "group__traits_group.html#ga28739ada7d796cf148964719975a4fcd", null ],
    [ "ENUM_UTILS_DEFINE_TRAITS_FL", "group__traits_group.html#gafd28c639cdd93319e21e701c8a483e83", null ]
];