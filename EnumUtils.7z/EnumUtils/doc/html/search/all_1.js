var searchData=
[
  ['bad_5fconversion_1',['bad_conversion',['../classenum__utils_1_1bad__conversion.html',1,'enum_utils']]],
  ['bad_5fmapping_2',['bad_mapping',['../classenum__utils_1_1bad__mapping.html',1,'enum_utils']]]
];
