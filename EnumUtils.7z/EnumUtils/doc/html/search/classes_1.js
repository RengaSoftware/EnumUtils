var searchData=
[
  ['bad_5fconversion_44',['bad_conversion',['../classenum__utils_1_1bad__conversion.html',1,'enum_utils']]],
  ['bad_5fmapping_45',['bad_mapping',['../classenum__utils_1_1bad__mapping.html',1,'enum_utils']]]
];
