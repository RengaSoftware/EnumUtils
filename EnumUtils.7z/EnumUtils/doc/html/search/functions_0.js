var searchData=
[
  ['convert_5fto_5fenum_56',['convert_to_enum',['../group__conversion_group.html#gae798aa8c729207fd32d5d5fe33b99949',1,'enum_utils::convert_to_enum(const T &amp;t)'],['../group__conversion_group.html#ga97debc23b8b206c9d58fd79b1c6ed3bd',1,'enum_utils::convert_to_enum(const T &amp;t, E default_value)']]],
  ['convert_5fto_5fvalue_57',['convert_to_value',['../group__conversion_group.html#ga2bd852befc94560c2bf88cfb134a8d8a',1,'enum_utils']]]
];
