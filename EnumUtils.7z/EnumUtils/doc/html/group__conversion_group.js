var group__conversion_group =
[
    [ "conversion_generator", "structenum__utils_1_1conversion__generator.html", [
      [ "impl", "structenum__utils_1_1conversion__generator_1_1impl.html", [
        [ "operator()", "structenum__utils_1_1conversion__generator_1_1impl.html#a88372c022a571f96b713411b102440ea", null ]
      ] ]
    ] ],
    [ "bad_conversion", "classenum__utils_1_1bad__conversion.html", null ],
    [ "ENUM_UTILS_DEFINE_CONVERSION", "group__conversion_group.html#ga4e32873e1c176e4c96a3e69c09220245", null ],
    [ "ENUM_UTILS_DEFINE_CONVERSION_TO_STRING", "group__conversion_group.html#ga0b7388517ed6eb1202c0debb7eefb3de", null ],
    [ "ENUM_UTILS_DEFINE_CONVERSION_TO_WSTRING", "group__conversion_group.html#ga403b33e08f50e45aba98360116e7f365", null ],
    [ "convert_to_enum", "group__conversion_group.html#gae798aa8c729207fd32d5d5fe33b99949", null ],
    [ "convert_to_enum", "group__conversion_group.html#ga97debc23b8b206c9d58fd79b1c6ed3bd", null ],
    [ "convert_to_value", "group__conversion_group.html#ga2bd852befc94560c2bf88cfb134a8d8a", null ]
];