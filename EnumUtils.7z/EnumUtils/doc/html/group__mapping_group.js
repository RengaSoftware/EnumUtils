var group__mapping_group =
[
    [ "bad_mapping", "classenum__utils_1_1bad__mapping.html", null ],
    [ "mapped_type", "structenum__utils_1_1mapped__type.html", null ],
    [ "mapped_value", "structenum__utils_1_1mapped__value.html", null ],
    [ "ENUM_UTILS_DEFINE_MAPPING_TO_TYPE", "group__mapping_group.html#gac6234def37d9d393d7325086e44f5a7b", null ],
    [ "ENUM_UTILS_DEFINE_MAPPING_TO_TYPE_TAG", "group__mapping_group.html#ga5f6ad540de88636a855b8d5d03696e2d", null ],
    [ "ENUM_UTILS_DEFINE_MAPPING_TO_VALUE", "group__mapping_group.html#gafc1da44075fa1a77aa2b22de730c86a2", null ],
    [ "mapped_enum", "group__mapping_group.html#ga0a7b15fec65af2da632b082ef3f340f9", null ],
    [ "mapped_type_t", "group__mapping_group.html#gae62b19fe405c6a43f78ecca6fbdccf74", null ],
    [ "map_to_enum", "group__mapping_group.html#ga9ebbecece243aa017743e419a3b51799", null ],
    [ "map_to_value", "group__mapping_group.html#gabf30fbe080b1344fa19501c8e21ca79f", null ],
    [ "try_map_to_enum", "group__mapping_group.html#gaac5e44a5dcc9797bf4f5b0bebcad95ba", null ]
];